@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo ========================================================================
echo   CAI DAT DU AN CAPCUT: Cua_Thep_TikTok_Luxury
echo ========================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_install_capcut.ps1"
if errorlevel 1 (
    echo [LOI] Khong the cai dat tu dong. Kiem tra lai thu muc CapCut hoac quyen truy cap!
) else (
    echo.
    echo Hay mo CapCut Desktop ^(tat mo lai neu dang mo^) va bam Export ^(Ctrl+E^)!
)
pause
