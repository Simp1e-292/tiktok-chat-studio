#!/bin/bash
set -e
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
CAPCUT_ROOT="$HOME/Movies/CapCut/User Data/Projects/com.lveditor.draft"
mkdir -p "$CAPCUT_ROOT"
DEST_DIR="$CAPCUT_ROOT/Cua_Thep_TikTok_Luxury"
rm -rf "$DEST_DIR"
cp -R "$SRC_DIR" "$DEST_DIR"
python3 - <<PY
import json, re, time
from pathlib import Path
dest = Path("$DEST_DIR")
dest_p = dest.as_posix()
root_p = Path("$CAPCUT_ROOT").as_posix()
for jf in ("draft_content.json", "draft_meta_info.json"):
    p = dest / jf
    if p.exists():
        txt = p.read_text(encoding="utf-8")
        txt = re.sub(r'"(?:[A-Za-z]:|/)[^"\r\n]*/assets/([^"]+)"', f'"{dest_p}/assets/\\1"', txt)
        p.write_text(txt, encoding="utf-8")
meta_p = dest / "draft_meta_info.json"
if meta_p.exists():
    meta = json.loads(meta_p.read_text(encoding="utf-8"))
    meta["draft_fold_path"] = dest_p
    meta["draft_root_path"] = root_p
    meta["draft_cover"] = f"{dest_p}/draft_cover.jpg"
    meta_p.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    rm_p = Path("$CAPCUT_ROOT") / "root_meta_info.json"
    if rm_p.exists():
        rm = json.loads(rm_p.read_text(encoding="utf-8"))
        stores = [d for d in rm.get("all_draft_store", []) if d.get("draft_name") != "Cua_Thep_TikTok_Luxury"]
        tmpl = dict(stores[0]) if stores else {}
        tmpl.update({
            "draft_name": "Cua_Thep_TikTok_Luxury",
            "draft_id": meta["draft_id"],
            "draft_fold_path": dest_p,
            "draft_root_path": root_p,
            "draft_json_file": f"{dest_p}/draft_content.json",
            "draft_cover": f"{dest_p}/draft_cover.jpg",
            "draft_new_version": "164.0.0",
            "draft_is_invisible": False,
            "draft_cloud_last_action_download": False,
            "draft_timeline_materials_size_": meta.get("draft_timeline_materials_size_", 0),
            "tm_duration": meta.get("tm_duration", 0),
            "tm_draft_create": meta.get("tm_draft_create", int(time.time() * 1000000)),
            "tm_draft_modified": int(time.time() * 1000000),
        })
        rm["all_draft_store"] = [tmpl] + stores
        rm_p.write_text(json.dumps(rm, ensure_ascii=False), encoding="utf-8")
PY
echo "✅ Đã cài đặt thành công vào CapCut Desktop: $DEST_DIR"
