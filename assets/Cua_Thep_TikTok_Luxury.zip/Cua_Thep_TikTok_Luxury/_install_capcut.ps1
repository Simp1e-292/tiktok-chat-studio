﻿$ErrorActionPreference = "Stop"
$src = $PSScriptRoot
if (-not $src) { $src = (Get-Location).Path }

$roots = @(
    (Join-Path $env:LOCALAPPDATA 'CapCut\User Data\Projects\com.lveditor.draft'),
    (Join-Path $env:LOCALAPPDATA 'JianyingPro\User Data\Projects\com.lveditor.draft')
)
$targetRoot = $roots | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $targetRoot) {
    $targetRoot = $roots[0]
    New-Item -ItemType Directory -Force -Path $targetRoot | Out-Null
}

$dest = Join-Path $targetRoot 'Cua_Thep_TikTok_Luxury'
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
Copy-Item -Recurse -Force $src $dest

Get-ChildItem -Path $dest -Filter 'desktop.ini' -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue

$destPosix = $dest -replace '\\', '/'
$rootPosix = $targetRoot -replace '\\', '/'

foreach ($jf in @('draft_content.json', 'draft_meta_info.json')) {
    $p = Join-Path $dest $jf
    if (Test-Path $p) {
        $txt = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
        $txt = [regex]::Replace($txt, '"(?:[A-Za-z]:|/)[^"\r\n]*/assets/([^"]+)"', ('"' + $destPosix + '/assets/$1"'))
        $txt = [regex]::Replace($txt, '"draft_fold_path"\s*:\s*"[^"]*"', ('"draft_fold_path": "' + $destPosix + '"'))
        $txt = [regex]::Replace($txt, '"draft_root_path"\s*:\s*"[^"]*"', ('"draft_root_path": "' + $rootPosix + '"'))
        $txt = [regex]::Replace($txt, '"draft_cover"\s*:\s*"[^"]*"', ('"draft_cover": "' + $destPosix + '/draft_cover.jpg"'))
        [System.IO.File]::WriteAllText($p, $txt, (New-Object System.Text.UTF8Encoding $false))
    }
}

$meta = [System.IO.File]::ReadAllText((Join-Path $dest 'draft_meta_info.json'), [System.Text.Encoding]::UTF8) | ConvertFrom-Json
$rootMetaPath = Join-Path $targetRoot 'root_meta_info.json'
if (Test-Path $rootMetaPath) {
    $rm = [System.IO.File]::ReadAllText($rootMetaPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    $list = @($rm.all_draft_store | Where-Object { $_.draft_name -ne 'Cua_Thep_TikTok_Luxury' })
    $entry = [PSCustomObject]@{
        draft_name = 'Cua_Thep_TikTok_Luxury'
        draft_id = $meta.draft_id
        draft_fold_path = $destPosix
        draft_root_path = $rootPosix
        draft_json_file = ($destPosix + '/draft_content.json')
        draft_cover = ($destPosix + '/draft_cover.jpg')
        draft_new_version = '164.0.0'
        draft_is_invisible = $false
        draft_cloud_last_action_download = $false
        draft_timeline_materials_size_ = [int64]($meta.draft_timeline_materials_size_)
        tm_duration = [int64]($meta.tm_duration)
        tm_draft_create = [int64]($meta.tm_draft_create)
        tm_draft_modified = [int64]($meta.tm_draft_modified)
    }
    $rm.all_draft_store = @($entry) + $list
    [System.IO.File]::WriteAllText($rootMetaPath, ($rm | ConvertTo-Json -Depth 12), (New-Object System.Text.UTF8Encoding $false))
}

Write-Host ("[OK] Da cai dat vao CapCut Desktop: " + $dest) -ForegroundColor Green
